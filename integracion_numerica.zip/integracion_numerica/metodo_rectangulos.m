
% Metodo de los rectangulos para el calculo de la integral numerica

function I = metodo_rectangulos(f, a, b, n)
    h = (b - a) / n;
    x = a + h*(0:n-1) + h/2;   % puntos medios
    I = h * sum(f(x));
end

