
%% Limpieza del espacio de trabajo y ventanas asociadas al script
clc;
clear;
close all;

%% Definición de la función
f = @(x) sin(x); a = 0; b = 2*pi; n = 10;

x = linspace(a, b, 1000);    % Definicion del dominio
y = f(x);                    % Evaluación de la función 
I_real = integral(f, a, b);  % Calculo de la integral analitica


%% Cálculo con métodos
I_rect = metodo_rectangulos(f, a, b, n); % Metodo del rectangulo
I_trap = metodo_trapecio(f, a, b, n);    % Metodo del trapecio
I_simp = metodo_simpson(f, a, b, n);     % Metodo de Simpson 1/3


%% Calculo de errores

error_rect = abs((I_real - I_rect) / I_real) * 100;
error_trap = abs((I_real - I_trap) / I_real) * 100;
error_simp = abs((I_real - I_simp) / I_real) * 100;

%% Tabla de resultados

% Obtener expresión de la función como texto
f_str = func2str(f);
f_str = strrep(f_str, '@(x)', '');

% Crear tabla
metodos = {'Rectángulos'; 'Trapecio'; 'Simpson 1/3'};
integrales = [I_rect; I_trap; I_simp];
errores = [error_rect; error_trap; error_simp];

T = table(metodos, integrales, errores, ...
          'VariableNames', {'Método', 'Integral', 'Error_Porcentual'});

fprintf('\nResultados para la función: %s en el intervalo [%.2f, %.2f] con n = %d\n\n', f_str, a, b, n);
disp(T);

fprintf('Valor real de la integral: %.6f\n\n', I_real);


%% Graficas 
% Rectángulos
h = (b - a) / n;
x_rect = a + h*(0:n-1) + h/2;
figure;
subplot(3,1,1);
hold on;
bar(x_rect, f(x_rect), 1, 'FaceAlpha', 0.3, 'FaceColor', 'b');
plot(x, y, 'r', 'LineWidth', 1.5);
title('Método de Rectángulos');
xlabel('x'); ylabel('f(x)');
grid on;

% Trapecios
x_trap = linspace(a, b, n+1);
y_trap = f(x_trap);
subplot(3,1,2);
hold on;
for i = 1:n
    fill([x_trap(i), x_trap(i), x_trap(i+1), x_trap(i+1)], ...
         [0, y_trap(i), y_trap(i+1), 0], 'g', 'FaceAlpha', 0.3);
end
plot(x, y, 'r', 'LineWidth', 1.5);
title('Método del Trapecio');
xlabel('x'); ylabel('f(x)');
grid on;

% Simpson
x_simp = linspace(a, b, n+1);
y_simp = f(x_simp);
subplot(3,1,3);
hold on;
plot(x, y, 'r', 'LineWidth', 1.5);
for i = 1:2:n-1
    xx = linspace(x_simp(i), x_simp(i+2), 100);
    coeffs = polyfit(x_simp(i:i+2), y_simp(i:i+2), 2);
    yy = polyval(coeffs, xx);
    fill([xx fliplr(xx)], [yy zeros(size(yy))], 'y', 'FaceAlpha', 0.3);
end
title('Método de Simpson 1/3');
xlabel('x'); ylabel('f(x)');
grid on;
