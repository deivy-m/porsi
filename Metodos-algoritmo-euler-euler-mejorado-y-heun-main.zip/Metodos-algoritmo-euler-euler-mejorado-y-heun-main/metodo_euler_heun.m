%% Programa que calcula la solucion numerica de una ecuacion diferencial euler - heun

clc; clear; close all;

%% Parametros iniciales
f = @(t,y) y -t^2 +1; %^ alt 94, definicion de la ecuacion diferencial como funcion anonima
a = 0; % Tiempo inicial de la simulacion
b = 5; % Tiempo final de la simulacion
h = 0.5; %Tmano del paso
N = (b - a) / h; % Numero de pasos
t = a:h:b; %Vectores de tiempo
%% Condicion inicial
y0 = 0.5;
%% Inicializacion de los vectores de almacenamiento de cada metodo
y_euler = zeros(1, N+1);
y_heun = zeros(1, N+1);
y_euler(1) = y0;
y_heun(1) = y0;
%% Metodo de Euler y Heun
for i=1:N
    y_euler(i+1) = y_euler(i) + h*f(t(i), y_euler(i));
    y_pred = y_heun(i) + h*f(t(i)), y_heun(i));
    y_heun(i+1) = y_heun(i) + h/2 *(f(t(i), y_heun(i)) + f(t(i+1), y_pred));
end  

%% Solucion analitica de una ecuacion diferencial
syms y(t_sym)
ode = diff(y,t_sym) == y - t_sym^2 +1;
cond = y(0) == y0;
ysol = dsolve(ode, cond);
f_sol = matlabfunctin(ysol);
y_analitica = f_sol(t);
disp('Solucion analitica de la E. D.')
pretty(ysol)

%% Tabla de visualizacion
T = table(t',y_analitica, y_euler, y_heun, ....
    'VariableNames',('t','Sol_Analitica', 'Euler', 'Euler Mejorado'));
disp('Tabla de resultados:');
disp(T)

%% Visualizacion
figure;
plot(t,y_analitica,'k--','LineWidth',3); hold on;
plot(t, y_euler, 'r--','LineWidth',1.5);
plot(t, y_heun)